"use strict";
exports.id = 373;
exports.ids = [373];
exports.modules = {

/***/ 8373:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$8": () => (/* binding */ isAuthenticated),
/* harmony export */   "EA": () => (/* binding */ user),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "r": () => (/* binding */ token),
/* harmony export */   "x4": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = `${"http://157.230.209.54:8000"}/api/`;
const login = async (email, password)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API_URL}login`, {
            email,
            password
        });
        const { token , user  } = response.data;
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(user));
        return token;
    } catch (error) {
        return false;
    }
};
const logout = async ()=>{
    try {
        await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API_URL}logout`, {}, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    } catch (error) {
        throw new Error("Error al cerrar sesi\xf3n");
    }
};
const isAuthenticated = ()=>!!localStorage.getItem("token");
const token = ()=>localStorage.getItem("token");
const user = ()=>JSON.parse(localStorage.getItem("user"));


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
"use strict";
exports.id = 373;
exports.ids = [373];
exports.modules = {

/***/ 8373:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "x4": () => (/* binding */ login)
/* harmony export */ });
/* unused harmony export isAuthenticated */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = `${"http://157.230.209.54:8000"}/api/`;
const login = async (email, password)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API_URL}login`, {
            email,
            password
        });
        const { token  } = response.data;
        localStorage.setItem("token", token);
        return token;
    } catch (error) {
        throw new Error("Error al autenticar usuario");
    }
};
const logout = async ()=>{
    try {
        await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API_URL}logout`, {}, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        localStorage.removeItem("token");
    } catch (error) {
        throw new Error("Error al cerrar sesi\xf3n");
    }
};
const isAuthenticated = ()=>!!localStorage.getItem("token");


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
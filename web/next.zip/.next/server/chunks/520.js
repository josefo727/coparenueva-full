exports.id = 520;
exports.ids = [520];
exports.modules = {

/***/ 8874:
/***/ ((module) => {

// Exports
module.exports = {
	"containerKpi": "FormKpi_containerKpi__Y_TK6",
	"kpi": "FormKpi_kpi__mf3CR",
	"goBack": "FormKpi_goBack__NejRl",
	"form": "FormKpi_form__cNHLu",
	"btnKpi": "FormKpi_btnKpi__6qCzl",
	"messageAlert": "FormKpi_messageAlert__FDynO"
};


/***/ }),

/***/ 3520:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormKpiUser)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8874);
/* harmony import */ var _styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function FormKpiUser({ kpi , setInput , selected , setSelected , setSelect , createKpi , updateKpi , isCreate =true , message  }) {
    const API_URL = `${"https://temporadaderenovaciones.bmicos.com"}`;
    const [months, setMonths] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const getMonths = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ()=>{
        setMonths(null);
        try {
            const resp = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${API_URL}/api/months`, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            setMonths(resp.data.months);
        } catch (e) {
            console.log(e);
        }
    }, []);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return months?.map((month)=>{
            return {
                value: month,
                label: month
            };
        });
    }, [
        months
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!months) {
            getMonths().then(()=>null);
        }
    }, [
        months
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!!kpi) {
            const MEMBER = options?.find((option)=>option.value === kpi?.month);
            setSelected(MEMBER);
        }
    }, [
        kpi
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (document.querySelector("#renewalTargetAudience")) {
            document.querySelector("#renewalTargetAudience").value = kpi?.renewal_target_audience || 0;
            document.querySelector("#renewedPolicies").value = kpi?.renewed_policies || 0;
            document.querySelector("#incentivePercentage").value = kpi?.incentive_percentage || 0;
            document.querySelector("#renewedPremium").value = kpi?.renewed_premium || 0;
            document.querySelector("#canceledPolicies").value = kpi?.canceled_policies || 0;
        }
    }, [
        kpi
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default().form),
            children: [
                isCreate ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    children: "Crear KPI"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    children: "Editar KPI"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "nextui-c-hzQjrs nextui-input-block-label",
                    htmlFor: "member",
                    children: "Mes"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_select__WEBPACK_IMPORTED_MODULE_4___default()), {
                    className: (_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default().inputs),
                    options: options,
                    value: selected,
                    onChange: (e)=>setSelect(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "renewalTargetAudience",
                    name: "renewal_target_audience",
                    bordered: true,
                    type: "number",
                    min: "0",
                    step: "1",
                    label: "P\xfablico objetivo de renovaci\xf3n",
                    defaultValue: kpi?.renewal_target_audience,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "renewedPolicies",
                    name: "renewed_policies",
                    bordered: true,
                    type: "number",
                    min: "0",
                    step: "1",
                    label: "P\xf3lizas renovadas",
                    defaultValue: kpi?.renewed_policies,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "incentivePercentage",
                    name: "incentive_percentage",
                    bordered: true,
                    type: "number",
                    min: "0",
                    step: "1",
                    label: "Porcentaje de incentivo",
                    defaultValue: kpi?.incentive_percentage,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "renewedPremium",
                    name: "renewed_premium",
                    bordered: true,
                    type: "number",
                    min: "0",
                    step: "1",
                    label: "Prima renovada",
                    defaultValue: kpi?.renewed_premium,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "canceledPolicies",
                    name: "canceled_policies",
                    bordered: true,
                    type: "number",
                    min: "0",
                    step: "1",
                    label: "P\xf3lizas canceladas",
                    defaultValue: kpi?.canceled_policies,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                message && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default().messageAlert),
                    children: message
                }),
                isCreate ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default().btnKpi),
                    onClick: ()=>createKpi(kpi),
                    children: "Crear"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_FormKpi_module_css__WEBPACK_IMPORTED_MODULE_5___default().btnKpi),
                    onClick: ()=>updateKpi(kpi),
                    children: "Editar"
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
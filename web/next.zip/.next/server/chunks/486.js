exports.id = 486;
exports.ids = [486];
exports.modules = {

/***/ 1274:
/***/ ((module) => {

// Exports
module.exports = {
	"card__mainImage": "FormLogin_card__mainImage__a9oHD",
	"form": "FormLogin_form__u2pnB",
	"email": "FormLogin_email__OwGvT",
	"user": "FormLogin_user__mDW71",
	"password": "FormLogin_password__Ag_BH",
	"LoginButton": "FormLogin_LoginButton__8XlHw"
};


/***/ }),

/***/ 6659:
/***/ ((module) => {

// Exports
module.exports = {
	"mainLogin": "Login_mainLogin__RXVGs"
};


/***/ }),

/***/ 4745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormLogin)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1274);
/* harmony import */ var _styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);




function FormLogin({ data , setInput , login  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3___default().form),
            onSubmit: (e)=>login(e),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Image, {
                    src: "/renoNegro.png",
                    alt: "background"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 0.5
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h", {
                    children: "Bienvenido"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "Por favor inicia sesi\xf3n para continuar."
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    name: "email",
                    value: data?.email,
                    onChange: (e)=>setInput(e),
                    className: (_styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3___default().user),
                    bordered: true,
                    placeholder: "Usuario*",
                    S: true,
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {
                    name: "password",
                    value: data?.password,
                    onChange: (e)=>setInput(e),
                    className: (_styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3___default().password),
                    bordered: true,
                    placeholder: "Contrase\xf1a*",
                    visibleIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeSlashFill, {}),
                    hiddenIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeFill, {}),
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "submit",
                    className: (_styles_FormLogin_module_css__WEBPACK_IMPORTED_MODULE_3___default().LoginButton),
                    children: "INGRESAR"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 2.5
                })
            ]
        })
    });
}


/***/ })

};
;
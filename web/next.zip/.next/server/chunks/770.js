exports.id = 770;
exports.ids = [770];
exports.modules = {

/***/ 3802:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "Navbar_navbar__66x_3",
	"nav": "Navbar_nav__b3Hnv",
	"logo": "Navbar_logo__E_Sw_",
	"navLink": "Navbar_navLink__vO2yE",
	"btnToggle": "Navbar_btnToggle__SRHoj",
	"contentTitle": "Navbar_contentTitle__8P6IA",
	"hamburger": "Navbar_hamburger__i8zx1",
	"navTitle": "Navbar_navTitle__uLb4Q",
	"navSubTitle": "Navbar_navSubTitle__iHVtC",
	"logout": "Navbar_logout__v3gWK"
};


/***/ }),

/***/ 8754:
/***/ ((module) => {

// Exports
module.exports = {
	"logo": "Sidebar_logo__vgpG6",
	"icon": "Sidebar_icon__czDJe",
	"main": "Sidebar_main__7sWL0",
	"contentSidebar": "Sidebar_contentSidebar__4Mhet",
	"menuItem": "Sidebar_menuItem__Gsdu6",
	"active": "Sidebar_active__5C3S5",
	"activeBookmark": "Sidebar_activeBookmark__IrSly",
	"collapse": "Sidebar_collapse__tKy9g",
	"collapsed": "Sidebar_collapsed__J7Ana"
};


/***/ }),

/***/ 6770:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Sidebars__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9227);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1981);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8373);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Sidebars__WEBPACK_IMPORTED_MODULE_2__, _auth__WEBPACK_IMPORTED_MODULE_4__]);
([_Sidebars__WEBPACK_IMPORTED_MODULE_2__, _auth__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function Layout({ children , title , description , navTitle , navSubTitle , ruta  }) {
    const [auth, setAuth] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (!(0,_auth__WEBPACK_IMPORTED_MODULE_4__/* .isAuthenticated */ .$8)()) {
            next_router__WEBPACK_IMPORTED_MODULE_6___default().push("/");
        } else {
            setAuth(true);
        }
    }, [
        _auth__WEBPACK_IMPORTED_MODULE_4__/* .isAuthenticated */ .$8
    ]);
    if (!auth) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_3__.ProSidebarProvider, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                            children: title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "Description",
                            content: description
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Sidebars__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    navTitle: navTitle,
                    navSubTitle: navSubTitle,
                    ruta: ruta,
                    children: children
                })
            ]
        })
    });
}
Layout.defaultProps = {
    title: "Proyecto",
    description: "Pagina del proyecto"
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2300:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavbarTop)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3802);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_gi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8866);
/* harmony import */ var react_icons_gi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_gi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8373);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth__WEBPACK_IMPORTED_MODULE_4__]);
_auth__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function NavbarTop({ navTitle , navSubTitle , toggle  }) {
    const USER = (0,_auth__WEBPACK_IMPORTED_MODULE_4__/* .user */ .EA)();
    const exit = async ()=>{
        await (0,_auth__WEBPACK_IMPORTED_MODULE_4__/* .logout */ .kS)();
        next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/");
    };
    const collapseItems = [
        "Features",
        "Customers",
        "Pricing",
        "Company",
        "Legal",
        "Team",
        "Help & Feedback",
        "Login",
        "Sign Up"
    ];
    const userDropdown = [
        {
            key: "logout",
            name: "Logout"
        }
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Navbar, {
        isBordered: true,
        variant: "sticky",
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().navbar),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Navbar.Brand, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: `showMobile ${(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().hamburger)}`,
                        onClick: ()=>toggle(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gi__WEBPACK_IMPORTED_MODULE_3__.GiHamburgerMenu, {})
                    }),
                    navSubTitle ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().contentTitle),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().navTitle),
                                children: navTitle
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().navSubTitle),
                                children: navSubTitle
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        b: true,
                        color: "inherit",
                        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().navTitle),
                        children: navTitle
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Navbar.Content, {
                enableCursorHighlight: true,
                variant: "underline",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
                    placement: "bottom-left",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Trigger, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.User, {
                                bordered: true,
                                as: "button",
                                size: "md",
                                name: USER?.name ? USER.name : "Renovador",
                                src: "/user.png"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Menu, {
                            color: "primary",
                            "aria-label": "User Actions",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Item, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__.BiLogOut, {}),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    onClick: ()=>exit(),
                                    children: "Logout"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9227:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Sidebars)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1981);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8754);
/* harmony import */ var _styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _NavbarTop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2300);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8373);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5856);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_go__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_NavbarTop__WEBPACK_IMPORTED_MODULE_3__, _auth__WEBPACK_IMPORTED_MODULE_5__]);
([_NavbarTop__WEBPACK_IMPORTED_MODULE_3__, _auth__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//icons





function Sidebars({ navTitle , navSubTitle , ruta , children  }) {
    const { collapseSidebar  } = (0,react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.useProSidebar)();
    const { toggleSidebar  } = (0,react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.useProSidebar)();
    const [iscollapse, setIsCollapse] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [toggled, setToggled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const USER = (0,_auth__WEBPACK_IMPORTED_MODULE_5__/* .user */ .EA)();
    const exit = async ()=>{
        await (0,_auth__WEBPACK_IMPORTED_MODULE_5__/* .logout */ .kS)();
        await next_router__WEBPACK_IMPORTED_MODULE_6___default().push("/");
    };
    const toggle = ()=>{
        setToggled(!toggled);
        toggleSidebar();
        if (!iscollapse) {
            setIsCollapse(!iscollapse);
            collapseSidebar();
        }
    };
    const collapse = ()=>{
        setIsCollapse(!iscollapse);
        collapseSidebar();
    };
    const resumen = ruta === "resumen" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const instructions = ruta === "instructions" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const playersBase = ruta === "playersBase" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const incentive = ruta === "incentive" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const team = ruta === "team" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const users = ruta === "users" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const specials = ruta === "specials" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const terms = ruta === "terms" ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)} ${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().active)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem)}`;
    const classCollapse = iscollapse ? `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().collapse)}` : `${(_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().collapsed)}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: {
            display: "flex"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.Sidebar, {
                style: {
                    display: "flex"
                },
                transitionDuration: 1000,
                breakPoint: "md",
                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().contentSidebar),
                backgroundColor: "#111419",
                ligth: true,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.Menu, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().logo),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_7__.Image, {
                                            src: "/Logo-BMI_RGB_blanco.png",
                                            fill: true,
                                            alt: "BMI"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__.BsFillGrid1X2Fill, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/resumen"
                                        }),
                                        className: resumen,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Resumen"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__.FaTasks, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/instrucciones"
                                        }),
                                        className: instructions,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Instrucciones"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__.BsFillFileTextFill, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/base-de-jugadores"
                                        }),
                                        className: playersBase,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Base de jugadores"
                                        ]
                                    }),
                                     false && /*#__PURE__*/ 0,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__.FaUsers, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/mi-equipo"
                                        }),
                                        className: team,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Agentes ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            " renovadores"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__.FaCog, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/casos-especiales"
                                        }),
                                        className: specials,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Casos Especiales"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_11__.GoChecklist, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/terminos-y-condiciones"
                                        }),
                                        className: terms,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "T\xe9rminos y ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            "condiciones"
                                        ]
                                    }),
                                    USER?.is_admin ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_12__.HiUsers, {
                                            className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                        }),
                                        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/usuarios"
                                        }),
                                        className: users,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().activeBookmark)
                                            }),
                                            "Usuarios"
                                        ]
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_10__.BiLogOut, {
                                    className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().icon)
                                }),
                                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().menuItem),
                                onClick: ()=>exit(),
                                children: "Cerrar sesi\xf3n"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: classCollapse,
                        hidein: "md",
                        onClick: ()=>collapse(),
                        children: iscollapse ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__.FaChevronLeft, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_9__.FaChevronRight, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: (_styles_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_13___default().main),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavbarTop__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        navTitle: navTitle,
                        navSubTitle: navSubTitle,
                        toggle: toggle
                    }),
                    children
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
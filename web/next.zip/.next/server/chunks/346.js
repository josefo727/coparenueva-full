exports.id = 346;
exports.ids = [346];
exports.modules = {

/***/ 427:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "FormUser_form__Ha_6x",
	"name": "FormUser_name__sqOwV",
	"email": "FormUser_email__96Cna",
	"url": "FormUser_url__zFfE4",
	"terms": "FormUser_terms__y3WxV",
	"password": "FormUser_password__qvSdM",
	"buttonCreateEdit": "FormUser_buttonCreateEdit__Ik1Qx"
};


/***/ }),

/***/ 4346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormUser)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(427);
/* harmony import */ var _styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);




function FormUser({ user , setInput , createUser , updateUser , isCreate =false  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().form),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1.5
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().name),
                    name: "name",
                    value: user?.name,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "Nombre*",
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().email),
                    name: "email",
                    value: user?.email,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "E-mail*",
                    required: true,
                    type: "email",
                    autocomplete: "off"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().url),
                    name: "url",
                    value: user?.url,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "URL"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().url),
                    name: "url_summary_detail",
                    value: user?.url_summary_detail,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "URL resumen"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {
                    bordered: true,
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().password),
                    name: "password",
                    label: "Contrase\xf1a*",
                    visibleIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeSlashFill, {}),
                    hiddenIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeFill, {}),
                    value: user?.password,
                    onChange: (e)=>setInput(e),
                    autocomplete: "off",
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                isCreate ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().buttonCreateEdit),
                        onClick: ()=>createUser(),
                        children: "Crear"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_3___default().buttonCreateEdit),
                        onClick: ()=>updateUser(),
                        children: "Editar"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1.5
                })
            ]
        })
    });
}


/***/ })

};
;
exports.id = 484;
exports.ids = [484];
exports.modules = {

/***/ 5806:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "FormSpecialCases_form__RmdRQ",
	"title": "FormSpecialCases_title__5sKPW",
	"messageAlert": "FormSpecialCases_messageAlert__pdlmn",
	"message": "FormSpecialCases_message__Uz56w",
	"evaluarCaso": "FormSpecialCases_evaluarCaso__jjGvk",
	"inputs": "FormSpecialCases_inputs__I0j8s",
	"goBack": "FormSpecialCases_goBack__wbgIu"
};


/***/ }),

/***/ 2887:
/***/ ((module) => {

// Exports
module.exports = {
	"containerSpecialCases": "SpecialCases_containerSpecialCases__5kS6L",
	"contentTextForm": "SpecialCases_contentTextForm__L5UMZ",
	"specialCases": "SpecialCases_specialCases__6cfeG",
	"FormSpecialCases": "SpecialCases_FormSpecialCases__wVNQ3",
	"specialCasesEdit": "SpecialCases_specialCasesEdit__GWZ0p",
	"containerTable": "SpecialCases_containerTable__QxRCQ",
	"table": "SpecialCases_table__0v77W",
	"actions": "SpecialCases_actions__lMibb",
	"contentDeleteConfirm": "SpecialCases_contentDeleteConfirm__BIW8Q",
	"deleteConfirm": "SpecialCases_deleteConfirm__XKUM8",
	"btnConfirm": "SpecialCases_btnConfirm__XFZ83",
	"btnCancel": "SpecialCases_btnCancel__js5Y5"
};


/***/ }),

/***/ 9185:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormSpecialCases)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5806);
/* harmony import */ var _styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function FormSpecialCases({ special , isEdit , getSpecialCases  }) {
    const API_URL = `${"https://temporadaderenovaciones.bmicos.com"}`;
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        member_id: "",
        email: "",
        detail: ""
    });
    const [alert, setAlert] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        value: null,
        label: null
    });
    const [members, setMembers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const getMembers = async ()=>{
        setMembers(null);
        const resp = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${API_URL}/api/members`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        setMembers(resp.data.data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getMembers().then(()=>null);
    }, []);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return members?.map((member)=>{
            return {
                value: member.id,
                label: member.name
            };
        });
    }, [
        members
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!!special) {
            setData(special);
            const MEMBER = options?.find((option)=>option.value === special?.member_id);
            setSelected(MEMBER);
        }
    }, [
        special
    ]);
    const setInput = (e)=>{
        setField(e.target.name, e.target.value);
    };
    const setSelect = (e)=>{
        setSelected(e);
        setField("member_id", e.value);
    };
    const setField = (field, value)=>{
        setData({
            ...data,
            [field]: value
        });
    };
    const ReportCase = async (res)=>{
        setAlert(false);
        console.log(res);
        if (!!res?.member_id && !!res?.email && !!res?.detail) {
            const headers = {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            };
            try {
                const response = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].post(`${API_URL}/api/special-cases`, res, headers);
                if (response.statusText === "Created") {
                    await getSpecialCases();
                    setMessage("Reporte creado satisfactoriamente.");
                    setData({
                        member_id: "",
                        email: "",
                        detail: ""
                    });
                    setSelected({
                        value: null,
                        label: null
                    });
                    setTimeout(()=>{
                        setMessage("");
                    }, 3000);
                }
            } catch (e) {
                console.log(e);
            }
        } else {
            setAlert(true);
        }
    };
    const updateSpecialCases = async (res)=>{
        if (!!res.member_id && !!res.email && !!res.detail) {
            const headers = {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            };
            try {
                const response = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].put(`${API_URL}/api/special-cases/${res.id}`, res, headers);
                if (response.statusText === "OK") {
                    setData({
                        member_id: "",
                        email: "",
                        detail: ""
                    });
                    next_router__WEBPACK_IMPORTED_MODULE_6___default().push("/casos-especiales");
                }
            } catch (e) {
                console.log(e);
            }
        } else {
            setAlert(true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.querySelector("#email").value = data?.email || "";
        document.querySelector("#detail").value = data?.detail || "";
    }, [
        data
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().form),
            children: [
                isEdit ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().goBack),
                    href: "/casos-especiales",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineArrowLeft, {}),
                        " regresar"
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().title),
                    children: "\xbfDeseas reportar un caso?"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 2
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "nextui-c-hzQjrs nextui-input-block-label",
                    htmlFor: "member",
                    children: "Miembro de equipo"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_select__WEBPACK_IMPORTED_MODULE_7___default()), {
                    id: "member",
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().inputs),
                    options: options,
                    value: selected,
                    onChange: (e)=>setSelect(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                    id: "email",
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().inputs),
                    clearable: true,
                    bordered: true,
                    label: "Correo electr\xf3nico",
                    name: "email",
                    type: "email",
                    defaultValue: data?.email,
                    onChange: (e)=>setInput(e),
                    required: "true"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Textarea, {
                    id: "detail",
                    clearable: true,
                    bordered: true,
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().inputs),
                    label: "Detalle de caso",
                    name: "detail",
                    defaultValue: data?.detail,
                    onChange: (e)=>setInput(e),
                    required: "true",
                    rows: 12
                }),
                alert ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().messageAlert),
                    children: "Todos los campos son requeridos"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                }),
                isEdit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().evaluarCaso),
                    onClick: ()=>updateSpecialCases(data),
                    children: "Editar"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().evaluarCaso),
                    onClick: ()=>ReportCase(data),
                    children: "EVALUAR"
                }),
                !!message ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_styles_FormSpecialCases_module_css__WEBPACK_IMPORTED_MODULE_8___default().message),
                    children: message
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_2__.Spacer, {
                    y: 1
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
exports.id = 368;
exports.ids = [368];
exports.modules = {

/***/ 427:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "FormUser_form__Ha_6x",
	"name": "FormUser_name__sqOwV",
	"email": "FormUser_email__96Cna",
	"url": "FormUser_url__zFfE4",
	"baseLine": "FormUser_baseLine__2X_g0",
	"terms": "FormUser_terms__y3WxV",
	"password": "FormUser_password__qvSdM",
	"buttonCreateEdit": "FormUser_buttonCreateEdit__Ik1Qx"
};


/***/ }),

/***/ 1108:
/***/ ((module) => {

// Exports
module.exports = {
	"containerUserCreate": "UserCreateEdit_containerUserCreate__mkt1F",
	"containerUserEdit": "UserCreateEdit_containerUserEdit__xaH1v",
	"userCreate": "UserCreateEdit_userCreate__f_Wi2",
	"userEdit": "UserCreateEdit_userEdit__cL2CI",
	"goBack": "UserCreateEdit_goBack__5HQ0K",
	"containerMyTeam": "UserCreateEdit_containerMyTeam__bMlyR",
	"contentUserImage": "UserCreateEdit_contentUserImage__bZo1_"
};


/***/ }),

/***/ 4346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormUser)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(427);
/* harmony import */ var _styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6735);
/* harmony import */ var _nextui_org_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);





function FormUser({ user , setInput , createUser , updateUser , isCreate =false  }) {
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        document.querySelector("#name").value = user?.name || "";
        document.querySelector("#email").value = user?.email || "";
        document.querySelector("#url").value = user?.url || "";
        document.querySelector("#urlDetail").value = user?.url_summary_detail || "";
        document.querySelector("#baseLine").value = user.base_line || 0;
        document.querySelector("#password").value = user?.password || "";
    }, [
        user
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().form),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1.5
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "name",
                    name: "name",
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().name),
                    defaultValue: user?.name,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "Nombre*",
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "email",
                    name: "email",
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().email),
                    defaultValue: user?.email,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "E-mail*",
                    required: true,
                    type: "email",
                    autocomplete: "off"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "url",
                    name: "url",
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().url),
                    defaultValue: user?.url,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "URL"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "urlDetail",
                    name: "url_summary_detail",
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().url),
                    defaultValue: user?.url_summary_detail,
                    onChange: (e)=>setInput(e),
                    bordered: true,
                    label: "URL resumen"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                    id: "baseLine",
                    name: "base_line",
                    type: "number",
                    min: "0",
                    step: "1",
                    bordered: true,
                    label: "Linea Base",
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().baseLine),
                    defaultValue: user?.base_line,
                    onChange: (e)=>setInput(e)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {
                    id: "password",
                    bordered: true,
                    className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().password),
                    name: "password",
                    label: "Contrase\xf1a*",
                    visibleIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeSlashFill, {}),
                    hiddenIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsEyeFill, {}),
                    defaultValue: user?.password,
                    onChange: (e)=>setInput(e),
                    autocomplete: "off",
                    required: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1
                }),
                isCreate ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().buttonCreateEdit),
                        onClick: ()=>createUser(),
                        children: "Crear"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        className: (_styles_FormUser_module_css__WEBPACK_IMPORTED_MODULE_4___default().buttonCreateEdit),
                        onClick: ()=>updateUser(),
                        children: "Editar"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nextui_org_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {
                    y: 1.5
                })
            ]
        })
    });
}


/***/ })

};
;